<?php

return [
    1,
    2,
    3,
    "asdbsdfasdfasf"
];

?>

{
"action": "REPRINT",
"order_id": "21_SYUS004419841",
"track_number": "94005112008810822083001",
"weight": 0.110,
"order_time": "2021-08-02 20:05:22",
"zone": 8,
"to": {
"company": "",
"name": "Groot Hsu",
"address1": "7179 Georgia 136",
"address2": "872",
"city": "Talking Rock",
"state": "GA",
"zip": "30175",
"country": "US"
},
"from": {
"company": "online seller",
"name": "online seller",
"address1": "555 E Orange Show Rd",
"address2": "",
"city": "San Bernardino",
"state": "CA",
"zip": "92408",
"country": "US"
},
"note_line": [
"21_SYUS004419841",
"635",
"something else"
]
}
