<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/04
 * Time: 10:28
 */

namespace common\services;

use yii\base\Model;

class Service extends Model
{

}