<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/06/21
 * Time: 15:41
 */

return [
    'ID' => 'ID',
    'Level' => 'Level',
    'Category' => 'Category',
    'Log Time' => 'Log Time',
    'Prefix' => 'Prefix',
    'Message' => 'Message',
];
