<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/02
 * Time: 17:54
 */

return [
    'Slug' => 'Slug',
    'Title' => 'Title',
    'Body' => 'Body',
    'View' => 'View',
    'Status' => 'Status',
];