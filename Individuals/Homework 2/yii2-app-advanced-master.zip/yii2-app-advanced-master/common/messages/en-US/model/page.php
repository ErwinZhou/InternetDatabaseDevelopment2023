<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/07/31
 * Time: 14:39
 */

return [
    'ID' => 'ID',
    'Uuid' => 'Uuid',
    'Slug' => 'Slug',
    'Title' => 'Title',
    'Body' => 'Body',
    'View' => 'View',
    'Status' => 'Status',
    'Created At' => 'Created At',
    'Updated At' => 'Updated At',
];