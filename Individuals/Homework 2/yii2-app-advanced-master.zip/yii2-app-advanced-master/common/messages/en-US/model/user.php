<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/04
 * Time: 10:34
 */

return [
    'ID' => 'ID',
    'Username' => 'Username',
    'Auth Key' => 'Auth Key',
    'Password Hash' => 'Password Hash',
    'Password Reset Token' => 'Password Reset Token',
    'Email' => 'Email',
    'Status' => 'Status',
    'Created At' => 'Created At',
    'Updated At' => 'Updated At',
];
