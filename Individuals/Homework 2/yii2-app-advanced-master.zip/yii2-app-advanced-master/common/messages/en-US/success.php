<?php
return [
    10000 => 'success',
];
