<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/06/21
 * Time: 15:44
 */

return [
    'ID' => 'ID',
    'Level' => '等级',
    'Category' => '分类',
    'Log Time' => '日志时间',
    'Prefix' => '前缀',
    'Message' => '消息',
];
