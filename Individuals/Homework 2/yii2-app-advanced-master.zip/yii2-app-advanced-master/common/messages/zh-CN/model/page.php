<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/07/31
 * Time: 14:40
 */

return [
    'ID' => 'ID',
    'Uuid' => '通用唯一识别码',
    'Slug' => '别名',
    'Title' => '标题',
    'Body' => '内容',
    'View' => '浏览',
    'Status' => '状态',
    'Created At' => '创建时间',
    'Updated At' => '更新时间',
];