<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/04
 * Time: 10:39
 */

return [
    'ID' => 'ID',
    'Username' => '用户名',
    'Auth Key' => '认证密钥',
    'Password Hash' => '密码哈希',
    'Password Reset Token' => '密码重置令牌',
    'Email' => '邮箱',
    'Status' => '状态',
    'Created At' => '创建时间',
    'Updated At' => '更新时间',
];
