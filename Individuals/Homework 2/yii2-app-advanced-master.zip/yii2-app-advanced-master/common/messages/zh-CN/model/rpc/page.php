<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/02
 * Time: 17:54
 */

return [
    'Slug' => '别名',
    'Title' => '标题',
    'Body' => '内容',
    'View' => '浏览',
    'Status' => '状态',
];