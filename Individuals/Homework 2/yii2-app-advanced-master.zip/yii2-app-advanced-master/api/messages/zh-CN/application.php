<?php
$commonMessages = require __DIR__ . '/../../../common/messages/zh-CN/application.php';
$messages = [
];
return $commonMessages + $messages;
