<?php
$commonMessages = require __DIR__ . '/../../../common/messages/en-US/application.php';
$messages = [
];
return $commonMessages + $messages;
