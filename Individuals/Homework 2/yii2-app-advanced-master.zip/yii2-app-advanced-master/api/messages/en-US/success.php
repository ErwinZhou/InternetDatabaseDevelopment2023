<?php
$commonMessages = require __DIR__ . '/../../../common/messages/en-US/success.php';
$messages = [
    124001 => 'Get log list success',
    124002 => 'Get log details success',
    124003 => 'Get page list success',
    124004 => 'Get page details success',
    124005 => 'Create page success',
    124006 => 'Update page success',
    124007 => 'Delete page success',
    126001 => 'Get user list success',
    126002 => 'Get user details success',
    126003 => 'Create user success',
    126004 => 'Update user success',
    126005 => 'Delete user success',
];
return $commonMessages + $messages;
