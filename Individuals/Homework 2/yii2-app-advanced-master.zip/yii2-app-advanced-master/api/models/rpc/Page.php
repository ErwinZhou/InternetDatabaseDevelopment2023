<?php

namespace api\models\rpc;

class Page extends \common\logics\rpc\Page
{

}
