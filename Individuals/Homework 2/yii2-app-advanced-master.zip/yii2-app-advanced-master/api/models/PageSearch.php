<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/07/31
 * Time: 11:31
 */

namespace api\models;

class PageSearch extends \common\logics\PageSearch
{

}
