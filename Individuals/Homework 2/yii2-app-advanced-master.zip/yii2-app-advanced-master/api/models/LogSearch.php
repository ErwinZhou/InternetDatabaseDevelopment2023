<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/06/22
 * Time: 13:43
 */

namespace api\models;

class LogSearch extends \common\logics\LogSearch
{

}
