<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/07/31
 * Time: 11:29
 */

namespace api\models;

/**
 * This is the ActiveQuery class for [[Page]].
 *
 * @see Page
 */
class PageQuery extends \common\logics\PageQuery
{

}
