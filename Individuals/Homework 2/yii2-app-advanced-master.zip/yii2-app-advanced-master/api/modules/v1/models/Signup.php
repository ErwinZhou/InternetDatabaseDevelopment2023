<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/08
 * Time: 10:48
 */

namespace api\modules\v1\models;


class Signup extends \api\models\Signup
{

}
