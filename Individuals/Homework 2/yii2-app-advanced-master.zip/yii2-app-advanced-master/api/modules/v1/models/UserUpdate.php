<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/08
 * Time: 11:19
 */

namespace api\modules\v1\models;


class UserUpdate extends \api\models\UserUpdate
{

}
