<?php
/**
 * Created by PhpStorm.
 * User: Qiang Wang
 * Date: 2018/08/02
 * Time: 13:04
 */

namespace api\modules\v1\models\rpc;

class Page extends \api\models\rpc\Page
{

}
