<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/06/22
 * Time: 13:46
 */

namespace api\modules\v1\models;


class LogSearch extends \api\models\LogSearch
{

}
