<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/07/31
 * Time: 13:06
 */

namespace api\modules\v1\models;


class PageSearch extends \api\models\PageSearch
{

}
