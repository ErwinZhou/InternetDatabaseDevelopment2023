<?php

namespace api\modules\v1\controllers;

/**
 * Log controller for the `v1` module
 */
class LogController extends \api\controllers\LogController
{
    public $modelClass = 'api\modules\v1\models\Log';
}
