<?php

namespace api\modules\v1\controllers;

/**
 * Page controller for the `v1` module
 */
class PageController extends \api\controllers\PageController
{
    public $modelClass = 'api\modules\v1\models\rpc\Page';
}
