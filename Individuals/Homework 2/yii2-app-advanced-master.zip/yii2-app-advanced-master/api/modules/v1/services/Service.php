<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/04
 * Time: 10:28
 */

namespace api\modules\v1\services;

class Service extends \api\services\Service
{

}