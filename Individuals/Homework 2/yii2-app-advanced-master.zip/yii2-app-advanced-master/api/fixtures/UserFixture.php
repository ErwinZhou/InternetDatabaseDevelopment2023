<?php
namespace api\fixtures;

class UserFixture extends \common\fixtures\UserFixture
{
}
