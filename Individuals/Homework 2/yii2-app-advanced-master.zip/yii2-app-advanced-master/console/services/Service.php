<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/04
 * Time: 10:28
 */

namespace console\services;

class Service extends \common\services\Service
{

}