<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/04
 * Time: 11:10
 */

namespace frontend\models;


class LoginForm extends \common\logics\LoginForm
{

}