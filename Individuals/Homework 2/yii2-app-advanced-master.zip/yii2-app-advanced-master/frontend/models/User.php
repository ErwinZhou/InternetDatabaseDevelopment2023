<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/04/04
 * Time: 10:44
 */

namespace frontend\models;

class User extends \common\logics\User
{

}
