<?php
return [
    // RPC HTTP 服务地址
    'rpc' => [
        'hostInfo' => 'http://rpc.github-shuijingwan-yii2-app-advanced.localhost', // HOME URL
        'baseUrl' => '/v1', // BASE URL
    ],
];
