<?php
return [
    'logDeleteReservedTime' => 15, // 日志的定时删除的保留时间(前 15 天)，单位为天
];
