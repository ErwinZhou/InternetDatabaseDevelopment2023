<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/02
 * Time: 10:53
 */

namespace rpc\models;

class PageSearch extends \common\logics\PageSearch
{

}
