<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/02
 * Time: 10:56
 */

namespace rpc\modules\v1\models;

/**
 * This is the ActiveQuery class for [[Page]].
 *
 * @see Page
 */
class PageQuery extends \rpc\models\PageQuery
{

}
