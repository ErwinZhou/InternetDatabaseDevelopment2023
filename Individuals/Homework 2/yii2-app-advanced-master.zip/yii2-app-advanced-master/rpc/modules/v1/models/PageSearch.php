<?php
/**
 * Created by PhpStorm.
 * User: WangQiang
 * Date: 2018/08/02
 * Time: 10:57
 */

namespace rpc\modules\v1\models;


class PageSearch extends \rpc\models\PageSearch
{

}
