<?php

namespace rpc\modules\v1\controllers;

/**
 * Page controller for the `v1` module
 */
class PageController extends \rpc\controllers\PageController
{
    public $modelClass = 'rpc\modules\v1\models\Page';
}
